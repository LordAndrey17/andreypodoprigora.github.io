/**
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */


#include "platform.h"
#include "mcc_generated_files/i2c_host/mssp1.h"
#include <stdbool.h>

#define DATALENGTH_01 3 // RegisterAdress[0], RegisterAdress[1], data || 1x uint 16 and 1x uint8
#define DATALENGTH_02 4 // RegisterAdress[0], RegisterAdress[1], data[0], data[1] || 2x uint 16
#define DATALENGTH_03 6 // RegisterAdress[0], RegisterAdress[1], data[0], data[1], data[2], data[3] || 1x uint16 and 1x uint32

uint8_t RB_Register_Buffer[2] = {0, 0};
uint8_t RW_Register_Buffer[2] = {0, 0};
uint8_t RW_Message_Buffer[2] = {0, 0};
uint8_t RDW_Register_Buffer[2] = {0, 0};
uint8_t RDW_Message_Buffer[4] = {0, 0, 0, 0};

uint8_t WB_Register_Buffer[2] = {0, 0};
uint8_t WB_Message_Buffer[3] = {0, 0, 0};
uint8_t WW_Register_Buffer[2] = {0, 0};
uint8_t WW_Message_Buffer[4] = {0, 0, 0, 0};
uint8_t WDW_Register_Buffer[2] = {0, 0};
uint8_t WDW_Message_Buffer[6] = {0, 0, 0, 0, 0, 0};

uint8_t VL53L4CD_RdDWord(Dev_t dev, uint16_t RegisterAdress, uint32_t *value)
{
	uint8_t status = 255;
    bool message_status = false;
	
	/* To be filled by customer. Return 0 if OK */
	/* Warning : For big endian platforms, fields 'RegisterAdress' and 'value' need to be swapped. */
    
    RDW_Register_Buffer[0] = (uint8_t)(RegisterAdress >> 8);
    RDW_Register_Buffer[1] = (uint8_t)(RegisterAdress & 0xFF);

    //READING FROM THE SENSOR
    message_status = I2C1_WriteRead(dev, &RDW_Register_Buffer, 2, &RDW_Message_Buffer, 4);
    __delay_ms(5);
    
    if(message_status == true){
        *value = ((uint32_t)RDW_Message_Buffer[0] << 24) + ((uint32_t)RDW_Message_Buffer[1] << 16) + ((uint32_t)RDW_Message_Buffer[2] << 8) + (uint32_t)RDW_Message_Buffer[3];
        status = 0;
    }
    
	return status;
}

uint8_t VL53L4CD_RdWord(Dev_t dev, uint16_t RegisterAdress, uint16_t *value)
{
	uint8_t status = 255;
    bool message_status = false;
	
	/* To be filled by customer. Return 0 if OK */
	/* Warning : For big endian platforms, fields 'RegisterAdress' and 'value' need to be swapped. */
    
    //FORMING THE REGISTER SPLITTING ARRAY
    RW_Register_Buffer[0] = (uint8_t)(RegisterAdress >> 8);
    RW_Register_Buffer[1] = (uint8_t)(RegisterAdress & 0xFF);
    
    //READING FROM THE SENSOR
    message_status = I2C1_WriteRead(41, &(RW_Register_Buffer), 2, &(RW_Message_Buffer), 2);
    __delay_ms(5);
    
    if(message_status == true){
        *value = (RW_Message_Buffer[0] << 8) + RW_Message_Buffer[1];
        status = 0;
    }
    
	return status;
}

uint8_t VL53L4CD_RdByte(Dev_t dev, uint16_t RegisterAdress, uint8_t *value)
{
	uint8_t status = 255;
    bool message_status = false;
	
	/* To be filled by customer. Return 0 if OK */
	/* Warning : For big endian platforms, fields 'RegisterAdress' and 'value' need to be swapped. */
    
    RB_Register_Buffer[0] = (uint8_t)(RegisterAdress >> 8);
    RB_Register_Buffer[1] = (uint8_t)(RegisterAdress & 0xFF);
    
    message_status = I2C1_WriteRead(dev, &RB_Register_Buffer, 2, value, 1);
    __delay_ms(5);
    
    if(message_status == true){
        status = 0;
    }
    
	return status;
}

uint8_t VL53L4CD_WrByte(Dev_t dev, uint16_t RegisterAdress, uint8_t value)
{
	uint8_t status = 255;
    bool message_status = false;
	
	/* To be filled by customer. Return 0 if OK */
	/* Warning : For big endian platforms, fields 'RegisterAdress' and 'value' need to be swapped. */
    
    WB_Register_Buffer[0] = (uint8_t)(RegisterAdress >> 8);
    WB_Register_Buffer[1] = (uint8_t)(RegisterAdress & 0xFF);
    
    WB_Message_Buffer[0] = WB_Register_Buffer[0];
    WB_Message_Buffer[1] = WB_Register_Buffer[1];
    WB_Message_Buffer[2] = value;

    //WRITING TO THE DESIRED REGISTER
    message_status = I2C1_Write(dev, &WB_Message_Buffer, 3);
    __delay_ms(5);

    if(message_status == true){
        status = 0;
    }
    
	return status;
}

uint8_t VL53L4CD_WrWord(Dev_t dev, uint16_t RegisterAdress, uint16_t value)
{
	uint8_t status = 255;
    bool message_status = false;
	
	/* To be filled by customer. Return 0 if OK */
	/* Warning : For big endian platforms, fields 'RegisterAdress' and 'value' need to be swapped. */
    
    WW_Register_Buffer[0] = (uint8_t)(RegisterAdress >> 8);
    WW_Register_Buffer[1] = (uint8_t)(RegisterAdress & 0xFF);
    
    WW_Message_Buffer[0] = WW_Register_Buffer[0];
    WW_Message_Buffer[1] = WW_Register_Buffer[1];
    WW_Message_Buffer[2] = value >> 8;
    WW_Message_Buffer[3] = value & 0x00FF;

    //WRITING TO THE DESIRED REGISTER
    message_status = I2C1_Write(dev, &WW_Message_Buffer, 4);
    __delay_ms(5);
    
    if(message_status == true){
        status = 0;
    }
    
	return status;
}

uint8_t VL53L4CD_WrDWord(Dev_t dev, uint16_t RegisterAdress, uint32_t value)
{
	uint8_t status = 255;
    bool message_status = false;
	
	/* To be filled by customer. Return 0 if OK */
	/* Warning : For big endian platforms, fields 'RegisterAdress' and 'value' need to be swapped. */
    
    WDW_Register_Buffer[0] = (uint8_t)(RegisterAdress >> 8);
    WDW_Register_Buffer[1] = (uint8_t)(RegisterAdress & 0xFF);
    
    WDW_Message_Buffer[0] = WDW_Register_Buffer[0];
    WDW_Message_Buffer[1] = WDW_Register_Buffer[1];
    WDW_Message_Buffer[2] = (value >> 24) & 0xFF;
    WDW_Message_Buffer[3] = (value >> 16) & 0xFF;
    WDW_Message_Buffer[4] = (value >>  8) & 0xFF;
    WDW_Message_Buffer[5] = (value >>  0) & 0xFF;

    //WRITING TO THE DESIRED REGISTER
    message_status = I2C1_Write(dev, &WDW_Message_Buffer, 6);
    __delay_ms(5);
    
    if(message_status == true){
        status = 0;
    }
    
	return status;
}
uint8_t VL53L4CD_WaitMs(Dev_t dev, uint32_t TimeMs)
{
	uint8_t status = 255;
	/* To be filled by customer */
    
    for(int i = 0; i < (int)TimeMs; i++ ){
         __delay_ms(1);
    }
    
	return status;
}

