 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/i2c_host/mssp1.h"
#include <stdio.h>
#include "platform.h"
#include "VL53L4CD_api.h"

uint16_t ms=0;
uint16_t ms_blinking=0;
uint16_t ms_blinking_th = 1000;

uint16_t sec=0;
uint16_t sec_01 = 0;

void timer_callback(void)
{
    ms++;
    ms_blinking++;
    
    if (ms>1000) 
    {
        ms -= 1000;
        sec++;
        sec_01++;
        LED_G_Toggle();
    }
    
    if(ms_blinking > ms_blinking_th){
        ms_blinking -= ms_blinking_th;
        LED_R_Toggle();
    }
}

void blinking(int mode){
    switch(mode){
        case 1:
            ms_blinking_th = 50;
            break;
        case 2: 
            ms_blinking_th = 100;
            break;
        case 3: 
            ms_blinking_th = 250;    
            break;   
        case 4: 
            ms_blinking_th = 500;    
            break;
        case 5: 
            ms_blinking_th = 1000;    
            break;
         
    
    }

}

void vip_blinking(int duration){
    for(int i = 0; i < duration; i++){
        LED_G_SetLow();
        LED_R_SetLow();
    
        __delay_ms(250);
    
        LED_G_SetHigh();
        LED_R_SetHigh();
    
        __delay_ms(250);
    }
}

uint16_t ABOLTUI;
    
void i2cTest(){
    
    bool result = VL53L4CD_RdWord(41, (0x010F), &ABOLTUI);

    if(ABOLTUI == 0xEBAA){
        LED_G_SetLow();
        __delay_ms(500);
        LED_G_SetHigh();
        __delay_ms(500);
            
        LED_G_SetLow();
        __delay_ms(500);
        LED_G_SetHigh();
        __delay_ms(500);
            
        LED_G_SetLow();
        __delay_ms(500);
        LED_G_SetHigh();
        __delay_ms(500);
    } else {
        LED_R_SetLow();
        __delay_ms(500);
        LED_R_SetHigh();
        __delay_ms(500);
            
        LED_R_SetLow();
        __delay_ms(500);
        LED_R_SetHigh();
        __delay_ms(500);
            
        LED_R_SetLow();
        __delay_ms(500);
        LED_R_SetHigh();
        __delay_ms(500);
    }
        
    __delay_ms(2000);
}

int main(void)
{
    SYSTEM_Initialize();
    
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts 
    // Use the following macros to: 

    // Enable the Global Interrupts 
    INTERRUPT_GlobalInterruptEnable(); 

    // Disable the Global Interrupts 
    //INTERRUPT_GlobalInterruptDisable(); 

    // Enable the Peripheral Interrupts 
    INTERRUPT_PeripheralInterruptEnable(); 

    // Disable the Peripheral Interrupts 
    //INTERRUPT_PeripheralInterruptDisable(); 
    
    //Initializing and starting the timer module
    TMR1_Initialize();
    TMR1_Start();
    TMR1_TMRInterruptEnable();

    TMR1_OverflowCallbackRegister(timer_callback);
    
    //Turning Off the LED-s on start
    LED_R_SetHigh();
    LED_G_SetHigh();
    
    vip_blinking(3);
     
    /*********************************/
	/*   VL53L4CD ranging variables  */
	/*********************************/

	Dev_t 					dev;
	uint8_t 				status, loop, isReady;
	uint16_t 				sensor_id;
	VL53L4CD_ResultsData_t 		results;		/* results data from VL53L4CD */
    
    /*********************************/
	/*      Customer platform        */
	/*********************************/

	/* Default VL53L4CD I2C address */
	dev = 41;

	/* (Optional) Change I2C address */
	// status = VL53L4CD_SetI2CAddress(dev, 0x20);
	// dev = 0x20;
    
    /*********************************/
	/*   Power on sensor and init    */
	/*********************************/
    
    I2C1_Initialize();
    
    VLT_OE_SetHigh();
    
    XSHUT_SetHigh();
    
    __delay_ms(1000);
    
	/* (Optional) Check if there is a VL53L4CD sensor connected */
    
    bool connected = false;
    
    while(!connected){
        status = VL53L4CD_GetSensorId(dev, &sensor_id);
        if(status || (sensor_id != 0xEBAA))
        {
            LED_R_SetLow();
            __delay_ms(250);
            LED_R_SetHigh();
            __delay_ms(250);
            
            LED_R_SetLow();
            __delay_ms(250);
            LED_R_SetHigh();
            __delay_ms(250);
            
            LED_R_SetLow();
            __delay_ms(250);
            LED_R_SetHigh();
            __delay_ms(250);
            
            __delay_ms(2000);
        }else{
            connected = true;
        }
    }

	/* (Mandatory) Init VL53L4CD sensor */
    
	status = VL53L4CD_SensorInit(dev);
	if(status)
	{
		//printf("VL53L4CD ULD Loading failed\n");
		return status;
	}

	//printf("VL53L4CD ULD ready !\n");
    
    /*********************************/
	/*         Ranging loop          */
	/*********************************/

	status = VL53L4CD_StartRanging(dev);
    
    while(1)
    {
        /* Use polling function to know when a new measurement is ready.
		 * Another way can be to wait for HW interrupt raised on PIN 7
		 * (GPIO 1) when a new measurement is ready */
 
		status = VL53L4CD_CheckForDataReady(dev, &isReady);

		if(isReady)
		{
			/* (Mandatory) Clear HW interrupt to restart measurements */
			VL53L4CD_ClearInterrupt(dev);

			/* Read measured distance. RangeStatus = 0 means valid data */
			VL53L4CD_GetResult(dev, &results);
//			printf("Status = %6u, Distance = %6u, Signal = %6u\n",
//				 results.range_status,
//				 results.distance_mm,
//				 results.signal_per_spad_kcps);
//			loop++;
            if((int)results.distance_mm > 10 && (int)results.distance_mm <= 50 ){
                blinking(1);
            }
            else if((int)results.distance_mm > 50 && (int)results.distance_mm <= 100){
                blinking(2);
            }
            else if((int)results.distance_mm > 100 && (int)results.distance_mm <= 150){
                blinking(3);
            }
            else if((int)results.distance_mm > 150 && (int)results.distance_mm <= 250){
                blinking(4);
            }
            else{
                blinking(5);
            }
		}

		/* Wait a few ms to avoid too high polling (function in platform
		 * file, not in API) */
		VL53L4CD_WaitMs(dev, 5);
    }
}