/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA0 aliases
#define LED_R_TRIS                 TRISAbits.TRISA0
#define LED_R_LAT                  LATAbits.LATA0
#define LED_R_PORT                 PORTAbits.RA0
#define LED_R_WPU                  WPUAbits.WPUA0
#define LED_R_OD                   ODCONAbits.ODCA0
#define LED_R_ANS                  ANSELAbits.ANSELA0
#define LED_R_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define LED_R_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define LED_R_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define LED_R_GetValue()           PORTAbits.RA0
#define LED_R_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define LED_R_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define LED_R_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define LED_R_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define LED_R_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define LED_R_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define LED_R_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define LED_R_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set RA1 aliases
#define LED_G_TRIS                 TRISAbits.TRISA1
#define LED_G_LAT                  LATAbits.LATA1
#define LED_G_PORT                 PORTAbits.RA1
#define LED_G_WPU                  WPUAbits.WPUA1
#define LED_G_OD                   ODCONAbits.ODCA1
#define LED_G_ANS                  ANSELAbits.ANSELA1
#define LED_G_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define LED_G_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define LED_G_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define LED_G_GetValue()           PORTAbits.RA1
#define LED_G_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define LED_G_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define LED_G_SetPullup()          do { WPUAbits.WPUA1 = 1; } while(0)
#define LED_G_ResetPullup()        do { WPUAbits.WPUA1 = 0; } while(0)
#define LED_G_SetPushPull()        do { ODCONAbits.ODCA1 = 0; } while(0)
#define LED_G_SetOpenDrain()       do { ODCONAbits.ODCA1 = 1; } while(0)
#define LED_G_SetAnalogMode()      do { ANSELAbits.ANSELA1 = 1; } while(0)
#define LED_G_SetDigitalMode()     do { ANSELAbits.ANSELA1 = 0; } while(0)

// get/set RB2 aliases
#define IO_RB2_TRIS                 TRISBbits.TRISB2
#define IO_RB2_LAT                  LATBbits.LATB2
#define IO_RB2_PORT                 PORTBbits.RB2
#define IO_RB2_WPU                  WPUBbits.WPUB2
#define IO_RB2_OD                   ODCONBbits.ODCB2
#define IO_RB2_ANS                  ANSELBbits.ANSELB2
#define IO_RB2_SetHigh()            do { LATBbits.LATB2 = 1; } while(0)
#define IO_RB2_SetLow()             do { LATBbits.LATB2 = 0; } while(0)
#define IO_RB2_Toggle()             do { LATBbits.LATB2 = ~LATBbits.LATB2; } while(0)
#define IO_RB2_GetValue()           PORTBbits.RB2
#define IO_RB2_SetDigitalInput()    do { TRISBbits.TRISB2 = 1; } while(0)
#define IO_RB2_SetDigitalOutput()   do { TRISBbits.TRISB2 = 0; } while(0)
#define IO_RB2_SetPullup()          do { WPUBbits.WPUB2 = 1; } while(0)
#define IO_RB2_ResetPullup()        do { WPUBbits.WPUB2 = 0; } while(0)
#define IO_RB2_SetPushPull()        do { ODCONBbits.ODCB2 = 0; } while(0)
#define IO_RB2_SetOpenDrain()       do { ODCONBbits.ODCB2 = 1; } while(0)
#define IO_RB2_SetAnalogMode()      do { ANSELBbits.ANSELB2 = 1; } while(0)
#define IO_RB2_SetDigitalMode()     do { ANSELBbits.ANSELB2 = 0; } while(0)

// get/set RB3 aliases
#define IO_RB3_TRIS                 TRISBbits.TRISB3
#define IO_RB3_LAT                  LATBbits.LATB3
#define IO_RB3_PORT                 PORTBbits.RB3
#define IO_RB3_WPU                  WPUBbits.WPUB3
#define IO_RB3_OD                   ODCONBbits.ODCB3
#define IO_RB3_ANS                  ANSELBbits.ANSELB3
#define IO_RB3_SetHigh()            do { LATBbits.LATB3 = 1; } while(0)
#define IO_RB3_SetLow()             do { LATBbits.LATB3 = 0; } while(0)
#define IO_RB3_Toggle()             do { LATBbits.LATB3 = ~LATBbits.LATB3; } while(0)
#define IO_RB3_GetValue()           PORTBbits.RB3
#define IO_RB3_SetDigitalInput()    do { TRISBbits.TRISB3 = 1; } while(0)
#define IO_RB3_SetDigitalOutput()   do { TRISBbits.TRISB3 = 0; } while(0)
#define IO_RB3_SetPullup()          do { WPUBbits.WPUB3 = 1; } while(0)
#define IO_RB3_ResetPullup()        do { WPUBbits.WPUB3 = 0; } while(0)
#define IO_RB3_SetPushPull()        do { ODCONBbits.ODCB3 = 0; } while(0)
#define IO_RB3_SetOpenDrain()       do { ODCONBbits.ODCB3 = 1; } while(0)
#define IO_RB3_SetAnalogMode()      do { ANSELBbits.ANSELB3 = 1; } while(0)
#define IO_RB3_SetDigitalMode()     do { ANSELBbits.ANSELB3 = 0; } while(0)

// get/set RC0 aliases
#define VLT_OE_TRIS                 TRISCbits.TRISC0
#define VLT_OE_LAT                  LATCbits.LATC0
#define VLT_OE_PORT                 PORTCbits.RC0
#define VLT_OE_WPU                  WPUCbits.WPUC0
#define VLT_OE_OD                   ODCONCbits.ODCC0
#define VLT_OE_ANS                  ANSELCbits.ANSELC0
#define VLT_OE_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define VLT_OE_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define VLT_OE_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define VLT_OE_GetValue()           PORTCbits.RC0
#define VLT_OE_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define VLT_OE_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define VLT_OE_SetPullup()          do { WPUCbits.WPUC0 = 1; } while(0)
#define VLT_OE_ResetPullup()        do { WPUCbits.WPUC0 = 0; } while(0)
#define VLT_OE_SetPushPull()        do { ODCONCbits.ODCC0 = 0; } while(0)
#define VLT_OE_SetOpenDrain()       do { ODCONCbits.ODCC0 = 1; } while(0)
#define VLT_OE_SetAnalogMode()      do { ANSELCbits.ANSELC0 = 1; } while(0)
#define VLT_OE_SetDigitalMode()     do { ANSELCbits.ANSELC0 = 0; } while(0)

// get/set RC3 aliases
#define XSHUT_TRIS                 TRISCbits.TRISC3
#define XSHUT_LAT                  LATCbits.LATC3
#define XSHUT_PORT                 PORTCbits.RC3
#define XSHUT_WPU                  WPUCbits.WPUC3
#define XSHUT_OD                   ODCONCbits.ODCC3
#define XSHUT_ANS                  ANSELCbits.ANSELC3
#define XSHUT_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define XSHUT_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define XSHUT_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define XSHUT_GetValue()           PORTCbits.RC3
#define XSHUT_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define XSHUT_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define XSHUT_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define XSHUT_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define XSHUT_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define XSHUT_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define XSHUT_SetAnalogMode()      do { ANSELCbits.ANSELC3 = 1; } while(0)
#define XSHUT_SetDigitalMode()     do { ANSELCbits.ANSELC3 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/